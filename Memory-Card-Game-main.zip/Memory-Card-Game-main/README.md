# Memory Card Game

## Live Demo

**You Can See The Project Live On:** [Here](https://gunseliunsal.github.io/Memory-Card-Game/)

Technologies:

- HTML
- CSS
- JS

#### Screenshots

<p><img align="center" src="memorygame1.png"/></p>

<p><img align="center" src="memorygame2.png"/></p>
